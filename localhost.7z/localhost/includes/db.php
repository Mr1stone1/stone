<?php
// Настройки подключения к базе данных
$host = 'localhost'; // Адрес сервера базы данных
$db = 'booking_system'; // Имя базы данных (убедитесь, что эта база данных существует)
$user = 'root'; // Имя пользователя по умолчанию для MySQL
$pass = ''; // Пустой пароль по умолчанию для пользователя root

try {
    // Создаем новое соединение с базой данных с использованием PDO
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    // Устанавливаем режим обработки ошибок
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // Обработка исключений: выводим сообщение об ошибке при подключении
    echo "Ошибка подключения: " . $e->getMessage();
}
?>