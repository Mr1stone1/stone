<?php
// Начинаем сессию для управления пользователями
session_start();

// Подключаемся к базе данных
include 'includes/db.php';

// Проверка, авторизован ли пользователь
if (!isset($_SESSION['user_id'])) {
    // Если пользователь не авторизован, перенаправляем на страницу входа
    header("Location: login.php");
    exit(); // Завершаем выполнение скрипта
}

// Проверка, был ли отправлен POST-запрос
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Получаем идентификатор пользователя из сессии
    $user_id = $_SESSION['user_id'];
    // Получаем данные из формы
    $master_id = $_POST['master_id'];
    $booking_date = $_POST['booking_date'];
    $booking_time = $_POST['booking_time'];

    // Проверка, существует ли уже запись с таким же временем для данного мастера
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE master_id = ? AND booking_date = ? AND booking_time = ?");
    $stmt->execute([$master_id, $booking_date, $booking_time]);
    $count = $stmt->fetchColumn(); // Получаем количество записей

    // Если запись уже существует, выводим сообщение об ошибке
    if ($count > 0) {
        echo "<p style='color: red;'>Ошибка: На это время уже есть запись для данного мастера.</p>";
    } else {
        // Если записи нет, добавляем новую
        $stmt = $pdo->prepare("INSERT INTO bookings (user_id, master_id, booking_date, booking_time) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $master_id, $booking_date, $booking_time]);
        echo "<p style='color: green;'>Заявка успешно подана!</p>"; // Уведомление об успешной подаче
    }
}

// Получаем список мастеров из базы данных
$masters = $pdo->query("SELECT * FROM masters")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создать новую заявку</title>
    <style>
        /* Стили для страницы создания новой заявки */
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            padding: 20px; 
            background-color: #f4f4f4; 
            border-radius: 5px; 
        } 
        h2 { 
            color: #333; 
        } 
        form { 
            margin-top: 20px; 
        } 
        select, input { 
            padding: 10px; 
            width: 100%; 
            max-width: 300px; 
            margin: 10px 0; 
            border: 1px solid #ccc; 
            border-radius: 5px; 
        } 
        button { 
            padding: 10px 15px; 
            background-color: #5cb85c; 
            color: white; 
            border: none; 
            cursor: pointer; 
            margin-top: 15px; 
        } 
        button:hover { 
            background-color: #4cae4c; 
        } 
        p { 
            margin: 10px 0; 
        }
    </style>
</head>
<body>
<a href="bookings.php">вернуться</a> <!-- Ссылка для возврата на страницу заявок -->
<h2>Создать новую заявку</h2>
<form method="POST">
    <label for="master_id">Выберите мастера:</label>
    <select name="master_id" required>
        <?php foreach ($masters as $master): ?>
            <option value="<?php echo $master['id']; ?>"><?php echo htmlspecialchars($master['name']); ?></option> <!-- Выводим список мастеров -->
        <?php endforeach; ?>
    </select>
    <label for="booking_date">Дата:</label>
    <input type="date" name="booking_date" required> <!-- Поле для выбора даты -->
    <label for="booking_time">Время:</label>
    <input type="time" name="booking_time" required min="08:00" max="18:00"> <!-- Поле для выбора времени с ограничениями -->
    <br>
    <button type="submit">Подать заявку</button> <!-- Кнопка для отправки формы -->
</form>
</body>
</html>
  
