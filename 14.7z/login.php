<?php
// Начинаем сессию для хранения данных о пользователе
session_start();

// Подключаемся к базе данных
include 'includes/db.php';

// Проверяем, был ли отправлен POST-запрос
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Получаем логин и пароль из формы
    $login = $_POST['login'];
    $password = $_POST['password'];

    // Проверка на обычного пользователя
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->execute([$login]);
    $user = $stmt->fetch(); // Извлекаем данные пользователя

    // Предопределенные данные для администратора
    $adminLogin = 'beauty';
    $adminPassword = 'pass';

    // Проверяем, существует ли пользователь и совпадает ли пароль
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id']; // Сохраняем идентификатор пользователя в сессии
        header("Location: bookings.php"); // Перенаправляем на страницу бронирования
        exit(); // Завершаем выполнение скрипта
    } 
    // Проверяем, является ли пользователь администратором
    elseif ($login === $adminLogin && $password === $adminPassword) {
        $_SESSION['user_id'] = 'admin'; // Сохраняем идентификатор администратора в сессии
        header("Location: admin.php"); // Перенаправляем на админ-панель
        exit(); // Завершаем выполнение скрипта
    } else {
        // Если логин или пароль неверны, выводим сообщение об ошибке
        echo "<p style='color:red;'>Неверный логин или пароль.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход</title>
    <style>
        /* Стили для страницы входа */
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            padding: 20px; 
            background-color: #f4f4f4; 
            border-radius: 5px; 
        } 
        h1 { 
            color: #333; 
        } 
        form { 
            margin-bottom: 20px; 
        } 
        label { 
            display: block; 
            margin: 10px 0 5px; 
        } 
        input { 
            padding: 10px; 
            width: 100%; 
            max-width: 300px; 
            margin: 10px 0; 
        } 
        button { 
            padding: 10px 15px; 
            background-color: #5cb85c; 
            color: white; 
            border: none; 
            cursor: pointer; 
            margin-top: 15px; 
        } 
        button:hover { 
            background-color: #4cae4c; 
        } 
        a { 
            display: block; 
            margin-top: 20px; 
            color: #007bff; 
            text-decoration: none; 
        } 
        a:hover { 
            text-decoration: underline; 
        }
    </style>
</head>
<body>
<h1>Вход</h1>
<form method="POST">
    <label for="login">Логин</label>
    <input type="text" name="login" placeholder="Логин" required>
    <label for="password">Пароль</label>
    <input type="password" name="password" placeholder="Пароль" required>
    <br>
    <button type="submit">Войти</button> <!-- Кнопка для отправки формы -->
</form>
<a href="register.php">Нет учетной записи? Зарегистрироваться</a> <!-- Ссылка на страницу регистрации -->
</body>
</html>
  