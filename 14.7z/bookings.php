<?php
// Начинаем сессию для управления пользователями
session_start();

// Подключаемся к базе данных
include 'includes/db.php';

// Проверка, авторизован ли пользователь
if (!isset($_SESSION['user_id'])) {
    // Если пользователь не авторизован, перенаправляем на страницу входа
    header("Location: login.php");
    exit(); // Завершаем выполнение скрипта
}

// Получаем идентификатор пользователя из сессии
$user_id = $_SESSION['user_id'];

// Запрос для получения всех заявок пользователя из базы данных
$stmt = $pdo->prepare("SELECT * FROM bookings WHERE user_id = ?");
$stmt->execute([$user_id]);
$bookings = $stmt->fetchAll(); // Получаем все заявки
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ваши заявки</title>
    <style>
        /* Стили для страницы заявок */
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            padding: 20px; 
            background-color: #f4f4f4; 
            border-radius: 5px; 
        } 
        h2 { 
            color: #333; 
        } 
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 20px; 
        } 
        th, td { 
            border: 1px solid #ddd; 
            padding: 8px; 
            text-align: left; 
        } 
        th { 
            background-color: #5cb85c; 
            color: white; 
        } 
        tr:hover { 
            background-color: #f1f1f1; 
        } 
        a { 
            display: inline-block; 
            margin-top: 20px; 
            padding: 10px 15px; 
            background-color: #007bff; 
            color: white; 
            text-decoration: none; 
            border-radius: 5px; 
        } 
        a:hover { 
            background-color: #0056b3; 
        }
    </style>
</head>
<body>
<h2>Ваши заявки</h2>
<table>
    <tr>
        <th>Мастер</th>
        <th>Дата</th>
        <th>Время</th>
        <th>Статус</th>
    </tr>
    <?php foreach ($bookings as $booking): ?>
        <tr>
            <td><?php echo htmlspecialchars($booking['master_id']); ?></td> <!-- Выводим идентификатор мастера -->
            <td><?php echo htmlspecialchars($booking['booking_date']); ?></td> <!-- Выводим дату бронирования -->
            <td><?php echo htmlspecialchars($booking['booking_time']); ?></td> <!-- Выводим время бронирования -->
            <td><?php echo htmlspecialchars($booking['status']); ?></td> <!-- Выводим статус заявки -->
        </tr>
    <?php endforeach; ?>
</table>
<a href="new_booking.php">Создать новую заявку</a> <!-- Ссылка на создание новой заявки -->
<a href="login.php">выход</a> <!-- Ссылка на выход из системы -->
</body>
</html>
  