<?php
include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $login = $_POST['login'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Проверка на существующий логин
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE login = ?");
    $stmt->execute([$login]);
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        echo "Логин уже существует. Пожалуйста, выберите другой логин.";
    } else {
        // Вставка нового пользователя
        $stmt = $pdo->prepare("INSERT INTO users (full_name, phone, login, password) VALUES (?, ?, ?, ?)");
        $stmt->execute([$full_name, $phone, $login, $password]);
        
        echo "Регистрация успешна!";
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <link rel="stylesheet" href="styles.css"> <!-- Подключение внешнего CSS файла -->
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            padding: 20px; 
            background-color: #f4f4f4; 
            border-radius: 5px; 
        } 
        h1 { 
            color: #333; 
        } 
        form { 
            margin-bottom: 20px; 
        } 
        label { 
            display: block; 
            margin: 10px 0 5px; 
        } 
        input { 
            padding: 10px; 
            width: 100%; 
            max-width: 300px; 
            margin: 10px 0; /* Добавлен отступ между полями ввода */
        } 
        button { 
            padding: 10px 15px; 
            background-color: #5cb85c; 
            color: white; 
            border: none; 
            cursor: pointer; 
            margin-top: 15px; /* Добавлен отступ сверху */
        } 
        button:hover { 
            background-color: #4cae4c; 
        } 
        a { 
            display: block; /* Сделаем ссылку блочной, чтобы она была на новой строке */
            margin-top: 20px; 
            color: #007bff; 
            text-decoration: none; 
        } 
        a:hover { 
            text-decoration: underline; 
        }
    </style>
</head>
<body>

<h1>Регистрация</h1>
<form method="POST">
    <label for="full_name">ФИО</label>
    <input type="text" name="full_name" placeholder="ФИО" required>
    
    <label for="phone">Телефон</label>
    <input type="text" name="phone" placeholder="Телефон" required>
    
    <label for="login">Логин</label>
    <input type="text" name="login" placeholder="Логин" required>
    
    <label for="password">Пароль</label>
    <input type="password" name="password" placeholder="Пароль" required>
    <br> 
    <button type="submit">Зарегистрироваться</button>
</form>

<p> Уже есть учетная запись? <a href="login.php"> Войти</a> <!-- Ссылка на страницу входа -->

</body>
</html>
