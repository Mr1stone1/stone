<?php
session_start();
include 'includes/db.php';

// Проверка, авторизован ли пользователь
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $master_id = $_POST['master_id'];
    $booking_date = $_POST['booking_date'];
    $booking_time = $_POST['booking_time'];

    // Проверка, существует ли уже запись с таким же временем для данного мастера
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE master_id = ? AND booking_date = ? AND booking_time = ?");
    $stmt->execute([$master_id, $booking_date, $booking_time]);
    $count = $stmt->fetchColumn();

    if ($count > 0) {
        echo "<p style='color: red;'>Ошибка: На это время уже есть запись для данного мастера.</p>";
    } else {
        // Если записи нет, добавляем новую
        $stmt = $pdo->prepare("INSERT INTO bookings (user_id, master_id, booking_date, booking_time) VALUES (?, ?, ?, ?)");
        $stmt->execute([$user_id, $master_id, $booking_date, $booking_time]);

        echo "<p style='color: green;'>Заявка успешно подана!</p>"; // Уведомление об успешной подаче
    }
}

$masters = $pdo->query("SELECT * FROM masters")->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создать новую заявку</title>
    <link rel="stylesheet" href="styles.css"> <!-- Подключение внешнего CSS файла -->
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            padding: 20px; 
            background-color: #f4f4f4; 
            border-radius: 5px; 
        } 
        h2 { 
            color: #333; 
        } 
        form { 
            margin-top: 20px; 
        } 
        select, input { 
            padding: 10px; 
            width: 100%; 
            max-width: 300px; 
            margin: 10px 0; /* Отступ между полями ввода */
            border: 1px solid #ccc; 
            border-radius: 5px; 
        } 
        button { 
            padding: 10px 15px; 
            background-color: #5cb85c; 
            color: white; 
            border: none; 
            cursor: pointer; 
            margin-top: 15px; /* Отступ сверху */
        } 
        button:hover { 
            background-color: #4cae4c; 
        } 
        p { 
            margin: 10px 0; 
        }
    </style>
</head>
<body>
<a href="bookings.php">вернуться</a>
<h2>Создать новую заявку</h2>
<form method="POST">
    <label for="master_id">Выберите мастера:</label>
    <select name="master_id" required>
        <?php foreach ($masters as $master): ?>
            <option value="<?php echo $master['id']; ?>"><?php echo htmlspecialchars($master['name']); ?></option>
        <?php endforeach; ?>
    </select>
    
    <label for="booking_date">Дата:</label>
    <input type="date" name="booking_date" required>
    
    <label for="booking_time">Время:</label>
    <input type="time" name="booking_time" required min="08:00" max="18:00"> <!-- Ограничение времени -->
    <br>
    <button type="submit">Подать заявку</button>
</form>

</body>
</html>
