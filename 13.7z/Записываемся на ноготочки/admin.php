<?php
session_start();
include 'includes/db.php';

// Функция для обновления статуса бронирования
function updateBookingStatus($pdo, $booking_id, $new_status) {
    $stmt = $pdo->prepare("UPDATE bookings SET status = ? WHERE id = ?");
    return $stmt->execute([$new_status, $booking_id]);
}

// Обработка изменения статуса бронирования
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['booking_id'], $_POST['status'])) {
    $booking_id = $_POST['booking_id'];
    $new_status = $_POST['status'];

    if (updateBookingStatus($pdo, $booking_id, $new_status)) {
        $message = "Сохранено."; // Изменено сообщение на "Сохранено."
    } else {
        $message = "Ошибка при обновлении статуса.";
    }

    // Перенаправление на ту же страницу для обновления данных
    header("Location: admin.php?message=" . urlencode($message));
    exit();
}

// Получение всех заявок
$bookings = $pdo->query("SELECT b.*, u.full_name, u.phone, m.name AS master_name FROM bookings b JOIN users u ON b.user_id = u.id JOIN masters m ON b.master_id = m.id")->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админская панель</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            padding: 20px; 
            background-color: #f4f4f4; 
            border-radius: 5px; 
        } 
        h2 { 
            color: #333; 
        } 
        form { 
            margin-bottom: 20px; 
        } 
        label { 
            display: block; 
            margin: 10px 0 5px; 
        } 
        input, select { 
            padding: 10px; 
            width: 100%; 
            max-width: 300px; 
            margin: 10px 0; /* Добавлен отступ между полями ввода */
        } 
        button { 
            padding: 10px 15px; 
            background-color: #5cb85c; 
            color: white; 
            border: none; 
            cursor: pointer; 
            margin-top: 15px; /* Добавлен отступ сверху */
        } 
        button:hover { 
            background-color: #4cae4c; 
        } 
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        .message {
            color: green;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<h2>Заявки</h2>
<?php if (isset($_GET['message'])): ?>
    <p class="message"><?php echo htmlspecialchars($_GET['message']); ?></p>
<?php endif; ?>
<table>
    <tr>
        <th>ФИО</th>
        <th>Телефон</th>
        <th>Мастер</th>
        <th>Дата</th>
        <th>Время</th>
        <th>Статус</th>
        <th>Действие</th>
    </tr>
    <?php foreach ($bookings as $booking): ?>
        <tr>
            <td><?php echo htmlspecialchars($booking['full_name']); ?></td>
            <td><?php echo htmlspecialchars($booking['phone']); ?></td>
            <td><?php echo htmlspecialchars($booking['master_name']); ?></td>
            <td><?php echo htmlspecialchars($booking['booking_date']); ?></td>
            <td><?php echo htmlspecialchars($booking['booking_time']); ?></td>
            <td><?php echo htmlspecialchars($booking['status']); ?></td>
            <td>
                <form method="POST">
                    <select name="status">
                        <option value="подтверждено" <?php echo ($booking['status'] == 'подтверждено') ? 'selected' : ''; ?>>Подтверждено</option>
                        <option value="отклонено" <?php echo ($booking['status'] == 'отклонено') ? 'selected' : ''; ?>>Отклонено</option>
                    </select>
                    <input type="hidden" name="booking_id" value="<?php echo htmlspecialchars($booking['id']); ?>">
                    <button type="submit">Изменить статус</button>
                </form>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

</body>
</html>